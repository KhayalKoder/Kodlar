# Maison Royale — Premium 3D Texas Hold'em Poker

Premium real-time multiplayer poker website with full 3D table, instant seating, and bot opponents.

## Stack
- **Backend**: FastAPI + WebSockets + MongoDB (motor) + JWT auth (bcrypt)
- **Frontend**: React 19 + React Three Fiber 9 + Tailwind + Framer Motion
- **Engine**: Server-authoritative Texas Hold'em with full hand evaluator

## Features
- Email/password authentication (JWT in httpOnly cookie + bearer for WebSocket)
- 6 stake tiers: $0.20/$0.40 (Micro) → $250/$500 (Elite)
- 12 tables (2 per tier), 5 seats each
- Quick-Seat: bots auto-fill empty seats so the game starts immediately
- 3D table rendered with three.js: midnight blue felt, gold trim, animated dust particles
- 30-second turn timer with visual countdown ring; auto-fold on timeout
- Persistent accounts, chip balance, avatars (6 personas)
- No bonuses, no promotional clutter — pure premium poker

## Project Layout

```
maison_royale/
├── backend/
│   ├── .env                  # MONGO_URL, DB_NAME, JWT_SECRET, FRONTEND_URL
│   ├── requirements.txt
│   ├── server.py             # FastAPI app, REST + WebSocket endpoints
│   ├── auth.py               # JWT + bcrypt helpers
│   ├── poker.py              # Deck, hand evaluator
│   └── game_manager.py       # Tables, players, game loop, bot AI
├── frontend/
│   ├── .env                  # REACT_APP_BACKEND_URL
│   ├── package.json
│   ├── craco.config.js
│   ├── tailwind.config.js
│   ├── postcss.config.js
│   ├── jsconfig.json
│   ├── public/
│   └── src/
│       ├── index.js
│       ├── App.js            # Router
│       ├── App.css
│       ├── index.css         # Fonts + theme
│       ├── lib/
│       │   ├── api.js
│       │   ├── avatars.js
│       │   └── auth-context.jsx
│       ├── pages/
│       │   ├── AuthPage.jsx
│       │   ├── Lobby.jsx
│       │   └── TablePage.jsx
│       └── components/
│           ├── PokerTable3D.jsx
│           ├── PlayingCard.jsx
│           ├── PlayerSeat.jsx
│           ├── ActionBar.jsx
│           ├── ui/           # shadcn components
│           └── ...
└── memory/
    ├── PRD.md
    └── test_credentials.md
```

## Local Setup

### Prerequisites
- Python 3.11+
- Node.js 20+
- MongoDB running on `mongodb://localhost:27017`
- Yarn (NOT npm)

### Backend
```bash
cd backend
pip install -r requirements.txt
# Edit .env: ensure MONGO_URL points to your Mongo
# JWT_SECRET should be a long random string (already provided in .env)
# FRONTEND_URL should match your frontend dev URL (e.g. http://localhost:3000)
uvicorn server:app --host 0.0.0.0 --port 8001 --reload
```

### Frontend
```bash
cd frontend
yarn install
# Edit .env: set REACT_APP_BACKEND_URL to your backend URL (e.g. http://localhost:8001)
yarn start
```

Open <http://localhost:3000>.

## Test Account
- Email: `test1@maison.com`
- Password: `test1234`
- 1000 starting chips

Or register a new account via the UI.

## API Quick Reference

| Method | Path | Body |
|---|---|---|
| POST | `/api/auth/register` | `{ email, password, username, avatar_id }` |
| POST | `/api/auth/login` | `{ email, password }` |
| POST | `/api/auth/logout` | – |
| GET  | `/api/auth/me` | – |
| PATCH| `/api/auth/avatar` | `{ avatar_id }` |
| GET  | `/api/tiers` | – |
| GET  | `/api/tables` | – |
| POST | `/api/tables/quick-seat` | `{ tier_id }` |
| POST | `/api/tables/leave` | – |
| WS   | `/api/ws/table/{table_id}?token=JWT` | – |

### WebSocket Messages

Send:
```json
{ "type": "action", "action": "fold" | "check" | "call" | "raise", "amount": 12.50 }
```

Receive:
```json
{ "type": "state", "data": { /* table state */ } }
```

## Notes
- **Important**: Avatars are pulled from `dicebear.com` (no key required).
- WebSocket auth accepts both cookie and `?token=` query param.
- Bot AI is intentionally simple (random + pot-odds weighting); easy to upgrade.
- The 3D scene is built imperatively (`scene.add()`) instead of R3F JSX to avoid conflicts with the visual-edits Babel plugin that injects `data-*` props.

## License
Private project — use as a base for your own poker app.
