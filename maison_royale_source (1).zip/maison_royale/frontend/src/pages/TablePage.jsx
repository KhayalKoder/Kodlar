import { useEffect, useRef, useState, useCallback } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "../lib/auth-context";
import { api, getWsUrl } from "../lib/api";
import PokerTable3D from "../components/PokerTable3D";
import PlayerSeat from "../components/PlayerSeat";
import ActionBar from "../components/ActionBar";
import { PlayingCard } from "../components/PlayingCard";

export default function TablePage() {
  const { tableId } = useParams();
  const { user, refresh } = useAuth();
  const [state, setState] = useState(null);
  const [connectStatus, setConnectStatus] = useState("connecting");
  const wsRef = useRef(null);
  const navigate = useNavigate();
  const [localTimeLeft, setLocalTimeLeft] = useState(30);

  const connect = useCallback(() => {
    const ws = new WebSocket(getWsUrl(tableId, user?.token || ""));
    wsRef.current = ws;
    ws.onopen = () => setConnectStatus("connected");
    ws.onmessage = (ev) => {
      try {
        const msg = JSON.parse(ev.data);
        if (msg.type === "state") {
          setState(msg.data);
          setLocalTimeLeft(msg.data.time_left ?? 30);
        }
      } catch (e) { /* ignore */ }
    };
    ws.onclose = () => {
      setConnectStatus("disconnected");
    };
    ws.onerror = () => setConnectStatus("error");
  }, [tableId, user]);

  useEffect(() => {
    if (!user) return;
    connect();
    return () => {
      try { wsRef.current?.close(); } catch (e) { /* noop */ }
    };
  }, [user, connect]);

  // Local countdown tick
  useEffect(() => {
    if (!state || state.action_pos < 0) return;
    const i = setInterval(() => setLocalTimeLeft((t) => Math.max(0, t - 1)), 1000);
    return () => clearInterval(i);
  }, [state?.action_pos, state?.stage]);

  const sendAction = (action, amount) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: "action", action, amount }));
    }
  };

  const leave = async () => {
    try { wsRef.current?.close(); } catch (e) { /* noop */ }
    try { await api.post("/tables/leave"); } catch (e) { /* noop */ }
    await refresh();
    navigate("/lobby");
  };

  if (!state) {
    return (
      <div className="min-h-screen w-full bg-[#05060a] text-zinc-400 flex items-center justify-center">
        <div className="text-center">
          <div className="font-serif text-2xl mb-2">Seating you at the table...</div>
          <div className="text-xs uppercase tracking-[0.4em] text-zinc-600">{connectStatus}</div>
        </div>
      </div>
    );
  }

  // Rotate seat indices so the current user is always at seat 0 (bottom)
  const yourSeat = state.your_seat;
  const seatMap = state.seats.map((p, originalIdx) => {
    const displayIdx = yourSeat == null ? originalIdx : (originalIdx - yourSeat + 5) % 5;
    return { originalIdx, displayIdx, player: p };
  });

  return (
    <div className="fixed inset-0 bg-[#05060a] text-[#F4F4F5] overflow-hidden">
      {/* 3D Table background */}
      <div className="absolute inset-0">
        <PokerTable3D />
      </div>

      {/* Top bar */}
      <div className="absolute top-0 inset-x-0 z-10 flex items-center justify-between px-6 py-4 bg-gradient-to-b from-black/80 to-transparent">
        <button
          onClick={leave}
          data-testid="leave-table"
          className="text-xs uppercase tracking-[0.3em] text-zinc-400 hover:text-[#D4AF37] border border-white/15 px-3 py-2 backdrop-blur"
        >
          ← Leave
        </button>
        <div className="text-center">
          <div className="font-serif text-lg md:text-2xl tracking-tight">{state.name}</div>
          <div className="text-[10px] uppercase tracking-[0.4em] text-[#D4AF37]">
            {state.tier.name} · ${state.tier.sb}/${state.tier.bb} · {state.stage}
          </div>
        </div>
        <div className="text-right text-[10px] uppercase tracking-[0.3em] text-zinc-500">
          Hand · <span className="text-[#D4AF37]">{state.community.length} cards</span>
        </div>
      </div>

      {/* Center: pot + community */}
      <div className="absolute left-1/2 top-[44%] -translate-x-1/2 -translate-y-1/2 z-10 flex flex-col items-center">
        <div className="text-[10px] uppercase tracking-[0.4em] text-zinc-400 mb-1">Pot</div>
        <motion.div
          key={state.pot}
          initial={{ scale: 1.1 }}
          animate={{ scale: 1 }}
          className="font-mono text-2xl text-[#D4AF37] mb-3"
          data-testid="pot-amount"
        >
          ${state.pot.toFixed(2)}
        </motion.div>
        <div className="flex gap-2 min-h-[80px] items-center">
          <AnimatePresence>
            {state.community.map((c, i) => (
              <motion.div
                key={c + i}
                initial={{ opacity: 0, y: -30, rotateY: 180 }}
                animate={{ opacity: 1, y: 0, rotateY: 0 }}
                transition={{ delay: i * 0.15 }}
              >
                <PlayingCard card={c} />
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>

      {/* Seats */}
      <div className="absolute inset-0 z-10 pointer-events-none">
        {seatMap.map(({ originalIdx, displayIdx, player }) => (
          <PlayerSeat
            key={originalIdx}
            seatIdx={displayIdx}
            player={player}
            isAction={originalIdx === state.action_pos}
            isDealer={originalIdx === state.dealer_pos}
            timeLeft={localTimeLeft}
            isYou={originalIdx === state.your_seat}
          />
        ))}
      </div>

      {/* Showdown overlay */}
      <AnimatePresence>
        {state.last_hand_summary && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-20 pointer-events-none flex items-center justify-center"
          >
            <div className="backdrop-blur-md bg-black/70 border border-[#D4AF37]/40 px-8 py-5 text-center">
              <div className="text-[10px] uppercase tracking-[0.4em] text-[#D4AF37] mb-2">Hand Complete</div>
              {state.last_hand_summary.winners.map((w, i) => (
                <div key={i} className="font-serif text-xl">
                  <span className="text-[#D4AF37]">{w.username}</span> {w.msg}{" "}
                  <span className="font-mono text-base">+${w.amount.toFixed(2)}</span>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Action bar */}
      <div className="absolute bottom-6 inset-x-0 z-10 pointer-events-none flex justify-center">
        <ActionBar state={state} onAction={sendAction} />
      </div>

      {/* Message log */}
      <div className="absolute top-24 right-4 z-10 max-w-[200px] hidden lg:block pointer-events-none">
        <div className="text-[9px] uppercase tracking-[0.3em] text-zinc-600 mb-1">Action Log</div>
        <div className="space-y-1 max-h-40 overflow-hidden">
          {state.messages.slice(-6).map((m, i) => (
            <div key={i} className="text-[11px] text-zinc-500 font-sans">{m}</div>
          ))}
        </div>
      </div>
    </div>
  );
}
