import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "../lib/auth-context";
import { formatApiErrorDetail } from "../lib/api";
import { AVATARS, avatarUrl } from "../lib/avatars";

const BG = "https://static.prod-images.emergentagent.com/jobs/03111c8f-043c-44ed-a4de-82eb92526462/images/eff4d0b7497e582804f24bc3e3d6f7f0017713c805230febbd62ad7ed318a1c1.png";

export default function AuthPage() {
  const [mode, setMode] = useState("login"); // login | register
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [avatarId, setAvatarId] = useState("man1");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const { login, register } = useAuth();
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      if (mode === "login") {
        await login(email, password);
      } else {
        await register({ email, password, username, avatar_id: avatarId });
      }
      navigate("/lobby");
    } catch (e) {
      setError(formatApiErrorDetail(e.response?.data?.detail) || e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-[#0A0A0C] text-[#F4F4F5]">
      {/* Background */}
      <div
        className="absolute inset-0 opacity-50"
        style={{
          backgroundImage: `url(${BG})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          filter: "blur(2px) brightness(0.5)",
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/60 to-black/90" />
      {/* Vignette grain */}
      <div className="absolute inset-0 pointer-events-none" style={{
        background: "radial-gradient(ellipse at center, transparent 0%, rgba(0,0,0,0.7) 100%)",
      }} />

      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center p-6">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mb-8 text-center"
        >
          <div className="text-xs tracking-[0.5em] text-[#D4AF37] mb-2 font-sans uppercase">Members Only</div>
          <h1 className="font-serif text-5xl md:text-6xl tracking-tight">
            Maison <span className="italic text-[#D4AF37]">Royale</span>
          </h1>
          <div className="mt-2 text-sm text-zinc-400 font-sans">Private Texas Hold'em · Established 2026</div>
        </motion.div>

        <motion.form
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.6 }}
          onSubmit={submit}
          className="w-full max-w-md backdrop-blur-2xl bg-black/60 border border-white/10 p-8 md:p-10 shadow-[0_20px_60px_rgba(0,0,0,0.6)]"
          data-testid="auth-form"
        >
          {/* Tabs */}
          <div className="flex gap-0 mb-8 border-b border-white/10">
            {["login", "register"].map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => setMode(m)}
                data-testid={`tab-${m}`}
                className={`flex-1 py-3 text-xs uppercase tracking-[0.3em] transition-all ${
                  mode === m ? "text-[#D4AF37] border-b-2 border-[#D4AF37] -mb-px" : "text-zinc-500 hover:text-zinc-300"
                }`}
              >
                {m === "login" ? "Enter" : "Register"}
              </button>
            ))}
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={mode}
              initial={{ opacity: 0, x: 6 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -6 }}
              transition={{ duration: 0.25 }}
              className="space-y-5"
            >
              {mode === "register" && (
                <>
                  <Field label="Display Name" value={username} onChange={setUsername} testid="input-username" required />
                  <div>
                    <div className="text-[10px] uppercase tracking-[0.3em] text-zinc-400 mb-3">Choose Persona</div>
                    <div className="grid grid-cols-6 gap-2">
                      {AVATARS.map((a) => (
                        <button
                          key={a.id}
                          type="button"
                          data-testid={`avatar-pick-${a.id}`}
                          onClick={() => setAvatarId(a.id)}
                          className={`relative aspect-square overflow-hidden border-2 transition-all ${
                            avatarId === a.id ? "border-[#D4AF37] scale-105" : "border-white/10 hover:border-white/30"
                          }`}
                        >
                          <img src={avatarUrl(a.id)} alt={a.name} className="w-full h-full object-cover" />
                        </button>
                      ))}
                    </div>
                  </div>
                </>
              )}
              <Field label="Email" value={email} onChange={setEmail} type="email" testid="input-email" required />
              <Field label="Password" value={password} onChange={setPassword} type="password" testid="input-password" required />
            </motion.div>
          </AnimatePresence>

          {error && (
            <div className="mt-5 text-xs text-red-400 border-l-2 border-red-400 pl-3" data-testid="auth-error">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            data-testid="auth-submit"
            className="mt-8 w-full bg-[#D4AF37] text-black font-sans uppercase tracking-[0.3em] text-xs py-4 hover:bg-[#F3E5AB] transition-colors disabled:opacity-50"
          >
            {loading ? "..." : mode === "login" ? "Enter the Salon" : "Create Account"}
          </button>
        </motion.form>
      </div>
    </div>
  );
}

function Field({ label, value, onChange, type = "text", required, testid }) {
  return (
    <label className="block">
      <span className="text-[10px] uppercase tracking-[0.3em] text-zinc-400 block mb-2">{label}</span>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        required={required}
        data-testid={testid}
        className="w-full bg-transparent border-b border-white/20 focus:border-[#D4AF37] outline-none py-2 text-base font-sans text-white placeholder:text-zinc-500 transition-colors"
      />
    </label>
  );
}
