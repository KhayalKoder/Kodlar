import { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { api, formatApiErrorDetail } from "../lib/api";
import { useAuth } from "../lib/auth-context";
import { avatarUrl } from "../lib/avatars";

export default function Lobby() {
  const { user, logout } = useAuth();
  const [tiers, setTiers] = useState([]);
  const [tables, setTables] = useState([]);
  const [activeTier, setActiveTier] = useState("micro");
  const [joining, setJoining] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const load = useCallback(async () => {
    const [{ data: t }, { data: tb }] = await Promise.all([api.get("/tiers"), api.get("/tables")]);
    setTiers(t);
    setTables(tb);
  }, []);

  useEffect(() => {
    load();
    const i = setInterval(load, 3000);
    return () => clearInterval(i);
  }, [load]);

  const quickSeat = async (tierId) => {
    setJoining(true);
    setError("");
    try {
      const { data } = await api.post("/tables/quick-seat", { tier_id: tierId });
      navigate(`/table/${data.table_id}`);
    } catch (e) {
      setError(formatApiErrorDetail(e.response?.data?.detail) || e.message);
    } finally {
      setJoining(false);
    }
  };

  const tablesByTier = tables.filter((t) => t.tier.id === activeTier);
  const currentTier = tiers.find((t) => t.id === activeTier);

  return (
    <div className="min-h-screen w-full bg-[#0A0A0C] text-[#F4F4F5]">
      {/* Top bar */}
      <header className="border-b border-white/5 backdrop-blur-md bg-black/40 sticky top-0 z-20">
        <div className="max-w-7xl mx-auto px-6 md:px-10 py-5 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="font-serif text-2xl tracking-tight">
              Maison <span className="italic text-[#D4AF37]">Royale</span>
            </h1>
          </div>
          <div className="flex items-center gap-6">
            <div className="hidden md:flex items-baseline gap-2">
              <span className="text-[10px] uppercase tracking-[0.3em] text-zinc-500">Bankroll</span>
              <span className="font-mono text-lg text-[#D4AF37]" data-testid="lobby-chips">
                ${user?.chips?.toFixed(2)}
              </span>
            </div>
            <div className="flex items-center gap-3">
              <img src={avatarUrl(user?.avatar_id)} alt="" className="w-9 h-9 object-cover border border-white/20" />
              <div className="hidden md:block">
                <div className="text-sm font-sans">{user?.username}</div>
                <button
                  onClick={async () => { await logout(); navigate("/auth"); }}
                  data-testid="logout-btn"
                  className="text-[10px] uppercase tracking-[0.3em] text-zinc-500 hover:text-[#D4AF37]"
                >
                  Sign out
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 md:px-10 py-10 md:py-16">
        {/* Hero */}
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
          <div className="text-xs tracking-[0.5em] text-[#D4AF37] mb-4 uppercase">The Lobby</div>
          <h2 className="font-serif text-4xl md:text-5xl lg:text-6xl tracking-tight max-w-3xl">
            Take your seat at the <span className="italic">finest</span> tables in town.
          </h2>
          <p className="text-zinc-400 mt-4 max-w-xl text-sm md:text-base font-sans">
            Five-seat private Texas Hold'em. No bonuses. No clutter. Instant entry — your seat is waiting.
          </p>
        </motion.div>

        {/* Stake selector */}
        <div className="mt-12 mb-6 flex flex-wrap gap-0 border-b border-white/10">
          {tiers.map((t) => (
            <button
              key={t.id}
              data-testid={`tier-tab-${t.id}`}
              onClick={() => setActiveTier(t.id)}
              className={`px-5 py-3 text-xs uppercase tracking-[0.3em] transition-all font-sans ${
                activeTier === t.id
                  ? "text-[#D4AF37] border-b-2 border-[#D4AF37] -mb-px"
                  : "text-zinc-500 hover:text-zinc-300"
              }`}
            >
              {t.name} · ${t.sb}/${t.bb}
            </button>
          ))}
        </div>

        {error && (
          <div className="text-red-400 text-sm mb-4 border-l-2 border-red-400 pl-3" data-testid="lobby-error">
            {error}
          </div>
        )}

        {/* Quick seat hero card */}
        {currentTier && (
          <motion.div
            key={activeTier}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="mb-10 relative overflow-hidden border border-[#D4AF37]/30 bg-gradient-to-br from-[#1c1c22] to-[#0A0A0C] p-8 md:p-12"
          >
            <div className="absolute -right-20 -top-20 w-80 h-80 rounded-full bg-[#D4AF37]/5 blur-3xl" />
            <div className="relative flex flex-col md:flex-row md:items-end justify-between gap-6">
              <div>
                <div className="text-[10px] uppercase tracking-[0.3em] text-[#D4AF37] mb-3">Instant Seat</div>
                <div className="font-serif text-3xl md:text-4xl">
                  {currentTier.name} Stakes · ${currentTier.sb} / ${currentTier.bb}
                </div>
                <div className="text-zinc-400 mt-3 text-sm font-sans">
                  Buy-in ${currentTier.min_buyin} – ${currentTier.max_buyin} · 5 seats · 30 second turn
                </div>
              </div>
              <button
                data-testid={`quick-seat-${activeTier}`}
                disabled={joining}
                onClick={() => quickSeat(activeTier)}
                className="bg-[#D4AF37] text-black font-sans uppercase tracking-[0.3em] text-xs py-4 px-8 hover:bg-[#F3E5AB] transition-colors disabled:opacity-50 whitespace-nowrap"
              >
                {joining ? "Seating..." : "Take a Seat"}
              </button>
            </div>
          </motion.div>
        )}

        {/* Tables grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {tablesByTier.map((table, idx) => (
            <motion.button
              key={table.id}
              data-testid={`table-card-${table.id}`}
              onClick={() => quickSeat(table.tier.id)}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              className="group text-left bg-[#131318] border border-white/10 hover:border-[#D4AF37]/60 p-6 transition-all hover:-translate-y-1"
            >
              <div className="flex items-start justify-between mb-6">
                <div>
                  <div className="text-[10px] uppercase tracking-[0.3em] text-zinc-500">Salon</div>
                  <div className="font-serif text-2xl mt-1">{table.name}</div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] uppercase tracking-[0.3em] text-zinc-500">Seats</div>
                  <div className="font-mono text-lg mt-1 text-[#D4AF37]">
                    {table.seats_filled}/{table.seats_total}
                  </div>
                </div>
              </div>
              {/* Seat dots */}
              <div className="flex gap-2 mb-6">
                {Array.from({ length: table.seats_total }).map((_, i) => (
                  <div
                    key={i}
                    className={`h-1.5 flex-1 ${i < table.seats_filled ? "bg-[#D4AF37]" : "bg-white/10"}`}
                  />
                ))}
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="font-sans uppercase tracking-[0.2em] text-zinc-500">
                  ${table.tier.sb} / ${table.tier.bb}
                </span>
                <span className="font-sans uppercase tracking-[0.2em] text-zinc-300 group-hover:text-[#D4AF37] transition-colors">
                  Join &rarr;
                </span>
              </div>
            </motion.button>
          ))}
        </div>
      </main>
    </div>
  );
}
