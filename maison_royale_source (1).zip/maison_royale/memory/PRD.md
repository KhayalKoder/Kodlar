# Maison Royale - Premium Poker (PRD)

## Original Problem Statement (Azerbaijani)
> Yalniz javascriptle. Mənə bir poker sayti lazimdi. Lobbisi olsun saytlar kimi, premium bir masa 5 neferlik masalardan, sadəcə içəri girdikcə gözləməsin isdifadəçi masa olan birbaşa girə bilsin, masada gözləmə vaxdi 30 saniyə. 0.20 sentdən 500 qədər otaqlar olsun. Hec bir bonus olmasin. Avatarlari olsun birce ona fikir vermeliyikki her cixis girisde yadda qalsin account, xais edirem 3D goruntulu olsun butun sayt, her yer. Premium olsun. Hami ilk girende ele acilsin otaq, otaq sade olmasin premium.

## User Choices
- Game: Texas Hold'em
- Multiplayer: Real-time (WebSocket)
- Auth: Email + password (JWT, persistent)
- Currency: Virtual chips (1000 starting)
- 3D: Full 3D table (React Three Fiber)

## Architecture
- Backend: FastAPI + WebSockets + MongoDB (motor)
- Frontend: React 19 + react-router + Tailwind + R3F 9 + framer-motion
- Auth: JWT (HS256) in httpOnly cookie + bearer-in-query fallback for WS
- Game engine: server-authoritative; bots auto-fill open seats

## Implemented (Feb 2026)
- Auth pages: Login / Register with avatar picker
- Persistent sessions via cookies (token also returned in body for WS auth)
- Lobby with 6 stake tiers and 2 tables per tier (12 total)
- Quick-Seat: instantly seats user at first open table in chosen tier; bots fill remaining seats
- 3D poker table (R3F 9): midnight blue felt, gold trim ring, leather rail, ambient/spot lighting, gold dust particles
- 5-seat oval layout with hero player always at bottom (rotated)
- Turn timer ring (30s) around active player; auto-fold on timeout
- Action bar: Fold / Check / Call / Bet/Raise slider / All-In
- Community cards animated in (preflop/flop/turn/river)
- Hand evaluator (high card to straight-flush) with showdown announcement
- Bot AI: probability-weighted check/call/raise/fold based on pot odds
- Premium dark "Jewel & Luxury" theme: Cormorant Garamond + Outfit; deep midnight + champagne gold
- No bonuses, no promotional content

## Backlog
- P1: Multiple humans at one table (UI works, only one tested simultaneously)
- P1: Hand history persistence per user
- P1: Chip-stack 3D visualization in front of each seat
- P2: Tournament/SnG format
- P2: Spectator mode
- P2: Custom avatar upload (object storage)
- P2: Chat at table

## Known Limitations
- Bot AI is intentionally simple (random with pot-odds weight)
- Hot reloads don't restart in-flight WS games; user must rejoin if backend restarts
- Single-server (no horizontal scaling of game state)
