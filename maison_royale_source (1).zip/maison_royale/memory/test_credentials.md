# Test Credentials

## Test Player Account
- Email: `test1@maison.com`
- Password: `test1234`
- Username: `TestPlayer`
- Starting Chips: 1000

## Second Test Account (create via register flow)
- Email: `test2@maison.com`
- Password: `test1234`
- Username: `Player2`

## Auth Endpoints
- POST `/api/auth/register` — { email, password, username, avatar_id }
- POST `/api/auth/login` — { email, password }
- POST `/api/auth/logout`
- GET `/api/auth/me`
- PATCH `/api/auth/avatar` — { avatar_id }

## Lobby Endpoints
- GET `/api/tiers`
- GET `/api/tables`
- POST `/api/tables/quick-seat` — { tier_id }
- POST `/api/tables/leave`

## Game WebSocket
- WS `/api/ws/table/{table_id}?token={jwt}`
- Send: `{ "type": "action", "action": "fold|check|call|raise", "amount": <number> }`
- Receive: `{ "type": "state", "data": {...} }`

## Notes
- Auth uses JWT in httpOnly cookies (secure=True, samesite=none) plus token in response body for WS auth (query param fallback).
- Stake tiers: micro ($0.20/$0.40), low ($1/$2), mid ($5/$10), high ($25/$50), vip ($100/$200), elite ($250/$500).
- Each table has 5 seats. Empty seats are auto-filled by bots so the game is always playable.
- Turn timer: 30 seconds; auto-fold/check on timeout.
- Avatars: man1, man2, man3, woman1, woman2, woman3.
